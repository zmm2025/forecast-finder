import datetime
from tkinter import *
from tkinter import ttk
from geopy.geocoders import Nominatim
import requests
import json
import datetime

# import states/cities data
with open("states_and_cities.json", "r") as file:
    states_data = json.load(file)

# create geolocator object
geolocator = Nominatim(user_agent="zmm2025@gmail.com")



# Main window
class ForecastFinder:

    def __init__(self, root):
        """
        Creates main window, manages its geometry, and creates/manages widgets
        """
        # window config & style
        root.title("Forecast Finder")
        root.iconbitmap("images\logo.ico")
        root.minsize(700, 425)
        root.maxsize(1000, 500)
        style = ttk.Style()
        style.configure("TFrame", background="#d9d9d9")
        style.configure("TLabel", background="#d9d9d9")

        # system menu
        root.option_add('*tearOff', FALSE)
        menubar = Menu(root)
        root["menu"] = menubar
        sysmenu = Menu(menubar, name='system')
        menubar.add_cascade(menu=sysmenu)
        sysmenu.add_command(label="Attributions", command=Attributions)

        # variables
        self.state = StringVar()
        self.city = StringVar()
        self.location = StringVar()

        # window geometry
        self.main_frame = ttk.Frame(root, padding=5)
        location_selectors_frame = ttk.Frame(self.main_frame)
        buttons_frame = ttk.Frame(self.main_frame)
        self.forecast_frame = ttk.Frame(self.main_frame, padding=(0, 15, 0, 0), width=700, height=300)

        # widgets
        logo_label = ttk.Label(self.main_frame, text="Forecast Finder", font=("TkDefualtfont", 12), compound="top")
        state_label = ttk.Label(location_selectors_frame, text="State:", justify="right")
        city_label = ttk.Label(location_selectors_frame, text="City:", justify="right")
        global states_data
        self.state_selector = ttk.Combobox(location_selectors_frame, textvariable=self.state, values=list(states_data.keys()), state=["readonly"])
        self.city_selector = ttk.Combobox(location_selectors_frame, textvariable=self.city, state=["disabled"])
        reset_button = ttk.Button(buttons_frame, text="Reset", command=self.resetSelectors)
        self.forecast_button = ttk.Button(buttons_frame, text="Find Forecast", command=self.findForecast, state=["disabled"])
        location_label = ttk.Label(self.main_frame, textvariable=self.location, font=("TkDefaultFont", 20))

        # add image to logo label widget
        # Images won't display unless a reference is maintained (See https://web.archive.org/web/20201111190625id_/http://effbot.org/pyfaq/why-do-my-tkinter-images-not-appear.htm)
        logo_label.icon = PhotoImage(file=("images\logo.png"))
        logo_label["image"] = logo_label.icon

        # widget event binding
        self.state_selector.bind("<<ComboboxSelected>>", lambda e: self.activateCitySelector())
        self.city_selector.bind("<<ComboboxSelected>>", lambda e: self.forecast_button.state(["!disabled"]))
        
        # widget grid placement
        self.main_frame.grid(sticky="NSEW")
        location_selectors_frame.grid(column=1, row=0, rowspan=2, sticky="NSEW")
        buttons_frame.grid(column=2, row=0, columnspan=3, sticky="NSEW")
        self.forecast_frame.grid(column=0, row=2, columnspan=5, rowspan=4, sticky="NSEW")
        logo_label.grid(column=0, row=0, rowspan=2)
        state_label.grid(column=0, row=0, sticky="E")
        city_label.grid(column=0, row=1, sticky="E")
        self.state_selector.grid(column=1, row=0, sticky="NSEW")
        self.city_selector.grid(column=1, row=1, sticky="NSEW")
        reset_button.grid(column=0, row=0, sticky="NSEW")
        self.forecast_button.grid(column=1, row=0, sticky="NSEW")
        location_label.grid(column=2, row=1, columnspan=3)

        # window resize handling
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        for i in range(5):
            self.main_frame.columnconfigure(i, weight=1)
        self.main_frame.rowconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)
        self.main_frame.rowconfigure(2, weight=5)
        location_selectors_frame.columnconfigure(0, weight=1)
        location_selectors_frame.columnconfigure(1, weight=2)
        location_selectors_frame.rowconfigure(0, weight=1)
        location_selectors_frame.rowconfigure(1, weight=1)
        buttons_frame.columnconfigure(0, weight=1)
        buttons_frame.columnconfigure(1, weight=1)
        buttons_frame.rowconfigure(0, weight=1)
        for i in range(5):
            self.forecast_frame.columnconfigure(i, weight=1)
        self.forecast_frame.rowconfigure(0, weight=1)
        self.forecast_frame.rowconfigure(1, weight=3)
        self.forecast_frame.rowconfigure(2, weight=2)
        self.forecast_frame.rowconfigure(3, weight=2)

    def activateCitySelector(self):
        """
        Clears/enables city selector and fills it with state's cities
        """
        self.city.set("")
        self.city_selector.state(["!disabled", "readonly"])
        self.city_selector["values"] = states_data[self.state.get()]
    
    def resetSelectors(self):
        """
        Clears selectors, disables city selector & forecast button, and destroys forecast widgets
        """
        self.state.set("")
        self.city.set("")
        self.location.set("")
        self.city_selector.state(["disabled"])
        self.forecast_button.state(["disabled"])
        
        for child in reversed(self.forecast_frame.grid_slaves()):
            child.destroy()

    def findForecast(self):
        """
        Clears forecast, finds 5-day forecast via OpenWeatherMap, parses data and creates/manages forecast widgets
        """
        # clear location destroy all forecast widgets
        self.location.set("")
        for child in reversed(self.forecast_frame.grid_slaves()):
            child.destroy()

        # create URL for OpenWeather One Call API call
        API_key = "[REDACTED]"
        self.location.set(self.city.get() + ", " + self.state.get())

        # geocode location for coordinates then request HTTP
        location = geolocator.geocode(self.location.get())
        OW_api_call_URL = f"https://api.openweathermap.org/data/2.5/onecall?lat={location.latitude}&lon={location.longitude}&exclude=current,minutely,hourly,alerts&units=imperial&appid={API_key}"
        response = requests.get(OW_api_call_URL)

        # if HTTP request is successful:
        if response.status_code == 200:
            
            # disable forecast button and retrieve HTTP response
            self.forecast_button.state(["disabled"])
            daily_forecast = response.json()["daily"]

            for day in daily_forecast:

                # variables
                day_index = daily_forecast.index(day)
                date = datetime.date.fromtimestamp(day["dt"]).strftime("%b") + " " + datetime.date.fromtimestamp(day["dt"]).strftime("%d").lstrip("0")
                weekday = datetime.date.fromtimestamp(day["dt"]).strftime("%A")
                temp = str(round( day["temp"]["day"] )) + "°"
                low = "Low: " + str(round( day["temp"]["min"] )) + "°"
                high = "High: " + str(round( day["temp"]["max"] )) + "°"
                feels_like = "Feels Like: " + str(round( day["feels_like"]["day"] )) + "°"
                humidity = "Humidity: " + str(day["humidity"]) + "%"
                wind_speed = "Wind Speed: " + str(round( day["wind_speed"] )) +  " mph"
                weather = day["weather"][0]["main"] + f" ({day['weather'][0]['description']})"

                # widgets
                day_frame = ttk.Frame(self.main_frame, borderwidth=2, relief="sunken")
                date_label = ttk.Label(day_frame, text=(weekday + "\n" + date), font=("TkDefaultFont", 13), justify="center")
                weather_label = ttk.Label(day_frame, text=weather, compound="top")
                temp_frame = ttk.Frame(day_frame, padding=(0, 10, 0, 5))
                temp_label = ttk.Label(temp_frame, text=temp, font=("TkDefaultFont", 25), justify="left")
                high_low_label = ttk.Label(temp_frame, text=(high + "\n" + low), justify="right")
                feels_like_label = ttk.Label(temp_frame, text=feels_like, justify="left")
                humidity_wind_label = ttk.Label(day_frame, text=(humidity + "\n" + wind_speed))

                # add image to weather label widget
                # Images won't display unless a reference is maintained (See https://web.archive.org/web/20201111190625id_/http://effbot.org/pyfaq/why-do-my-tkinter-images-not-appear.htm)
                weather_label.icon = PhotoImage(file=(f"images\weather_icons\{day['weather'][0]['icon']}@2x.png"))
                weather_label["image"] = weather_label.icon
                
                # widget grid placement
                day_frame.grid(column=day_index, row=2, sticky="NSEW")
                date_label.grid(column=0, row=0)
                weather_label.grid(column=0, row=1)
                temp_frame.grid(column=0, row=2)
                temp_label.grid(column=0, row=0)
                high_low_label.grid(column=1, row=0)
                feels_like_label.grid(column=0, row=1, columnspan=2, sticky="NW")
                humidity_wind_label.grid(column=0, row=3)

                # restrict to 5-day forecast
                if daily_forecast.index(day) == 4:
                    break

        # if HTTP request is unsuccessful:
        else:
            self.location.set(f"HTTP Error {response.status_code}")
            print("Forecast Finder - There was an unexpected error in the HTTP request. Please try again later.")
            print(f"Forecast Finder - HTTP status code: {response.status_code}")



# Attributions window
class Attributions:
    
    def __init__(self):
        """
        Creates/configures/manages window and all widgets
        """
        # window config
        win = Toplevel(root)
        win.title("Attributions")
        win.iconbitmap("images\logo.ico")
        win.resizable(FALSE,FALSE)
        
        # window geometry
        main_frame = ttk.Frame(win, padding=10)
        main_frame.grid(sticky="NSEW")

        # attribution label
        attribution = "Program created by Zain McCoy\nIcons made by Freepik from www.flaticon.com\nWeather information from OpenWeatherMap"
        lbl = ttk.Label(main_frame, text=attribution, font=("TkDefaultFont", 15), justify="center")
        lbl.grid(column=0, row=0, sticky="NSEW")



if __name__ == "__main__":
    root = Tk()
    ForecastFinder(root)
    root.mainloop()